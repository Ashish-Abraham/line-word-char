Python program using cv2, os and PIL
Terminal used: Windows CMD
Text Editor: VS Code

->reads scanned documents in jpg or png using cv2
->saves letters, words and lines to their respective folders using PIL and os
